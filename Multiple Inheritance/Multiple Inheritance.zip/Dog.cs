﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Multiple_Inheritance
{
    public class Dog:Animal
    {
        public void Bark()
        {
            Console.WriteLine("barking...");
        }
    }
}
